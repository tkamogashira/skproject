% High channel density version of the PZFC

ValParam = [...
% Filed, Nfit = 524, 11-3 parameters, PZFC, cwt 0, fit time 9915 sec
      1.14827   0.00000   0.00000 % SumSqrErr=  10125.41
      0.53571  -0.70128   0.63246 % RMSErr   =   2.81586
      0.76779   0.00000   0.00000 % MeanErr  =   0.00000
          Inf   0.00000   0.00000 % RMSCost  =       NaN
      0.00000   0.00000   0.00000
      6.00000   0.00000   0.00000
      1.08869  -0.09470   0.07844
     10.56432   2.52732   1.86895
%    -3.45865  -1.31457   3.91779 % Kv 
];
